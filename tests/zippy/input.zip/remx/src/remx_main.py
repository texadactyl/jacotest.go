'''
Remote execution using ssh based on a config file.
It is assumed that the configured user ID is trusted
   based on an ssh digital certificate.
'''
import os
import sys
import threading
import time

import remx_utilities as util
import remx_cfg as cfg

# ----------------------------------------------------------
# remupd_main command line validation:
# 1) This is a main program
# 2) Python 3
# 3) This is a main program
# 4) There is exactly one command-line parameter: the config file path
# ----------------------------------------------------------
if __name__ != "__main__":
    print("*** Must be a main program")
    sys.exit(86)
if sys.version_info[0] < 3:
    print("*** Requires Python 3")
    sys.exit(86)
NARGS = len(sys.argv)
if NARGS != 2:
    print("*** Must have exactly one parameter: the path of the config file")
    sys.exit(86)

class MyThread(threading.Thread):
    '''
    MyThread class based on Python 3 class 'threadingThread':
        __init__: object initialization
        run: execute object thread
    '''
    def __init__(self, arg_thread_id, arg_name):
        threading.Thread.__init__(self)
        self.thread_id = arg_thread_id
        self.name = arg_name
        self.log_path = "*TBD*"
        self.log_handle = 0
        self.success = False
    def run(self):
        self.success = util.remote_exec(self)
        if self.success:
            util.log_write(self, "* * * * * Success * * * * *")
        else:
            util.log_write(self, "* * * * * Failure * * * * *")
        util.log_close(self)

# ----------------------------------------------------------
# Thread initialization
# ----------------------------------------------------------
def create_thread(arg_thread_id, arg_host_name):
    '''
    Create a new thread and return its handle.
    '''
    if cfg.FLAG_DEBUGGING:
        print("create_thread: DEBUG id=%d, host_name=%s" % (arg_thread_id, arg_host_name))
    out_thread = MyThread(arg_thread_id, arg_host_name)
    log_folder = "./logs"
    if not os.path.exists(log_folder):
        os.mkdir(log_folder)
    util.log_open(out_thread, log_folder + "/" + str(arg_thread_id)
                  + "." + arg_host_name + ".log")
    if arg_thread_id < 1:
        util.log_write(out_thread, "Log folder = %s", os.path.abspath(log_folder))
    return out_thread

# ----------------------------------------------------------
# Main
# ----------------------------------------------------------

# Count ping failures
poops = 0

# Get path of config file
CFG_PATH = sys.argv[1]

# Create main thread
MAIN_THREAD = create_thread(0, "main")

# Open config file
if not cfg.parser(MAIN_THREAD, CFG_PATH):
    util.log_write(MAIN_THREAD, "*** Config file (%s) errors", CFG_PATH)
    sys.exit(86)

# Start all child threads from the configured list of hosts
if cfg.FLAG_DEBUGGING:
    util.log_write(MAIN_THREAD, "DEBUG %d host_list entries", len(cfg.host_list))
    util.log_write(MAIN_THREAD, "DEBUG host_list = %s", str(cfg.host_list))
threads = []
counter = 0
for this_host in cfg.host_list:
    counter = counter + 1
    child_thread = create_thread(counter, this_host)
    child_thread.start()
    threads.append(child_thread)
util.log_write(MAIN_THREAD, "Started %d child threads", len(threads))

# Wait for all child threads to complete
num_child_threads = len(threads)
while not time.sleep(1):
    for child_thread in threads:
        if not child_thread.is_alive():
            util.log_write(MAIN_THREAD, "Child thread completed: %d.%s",
                           child_thread.thread_id, child_thread.name)
            if not child_thread.success:
                poops += 1
            threads.remove(child_thread)
        if len(threads) < 1:
            if poops > 0:
                util.log_write(MAIN_THREAD, "*** At least one child thread failed")
            else:
                util.log_write(MAIN_THREAD,
                               "All {} child threads have completed successfully"
                               .format(num_child_threads))
            util.log_close(MAIN_THREAD)
            sys.exit(0)
