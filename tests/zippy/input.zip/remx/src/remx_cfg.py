"""
Configuration Parser
"""
import os
import ast
import configparser
import remx_utilities as util

SECTION_NAME = "EVERYTHING"
FLAG_DEBUGGING = False
FLAG_TEST_FOR_REBOOT = False
host_list = []
remote_user_id = "*TBD*"
command = "*TBD*"
cmd_test_for_reboot = "*TBD*"
ping_timeout = 0
ping_attempts = 0

def dump_parms(arg_from):
    """
    Show all configuration parameters
    """
    print("\nDump cfg from {}: FLAG_DEBUGGING={}, FLAG_TEST_FOR_REBOOT={}, host_list={}, remote_user_id={}, command={}, cmd_test_for_reboot={}, ping_timeout={}, ping_attempts={}\n"
          .format(arg_from, FLAG_DEBUGGING, FLAG_TEST_FOR_REBOOT, host_list,
                  remote_user_id, command, cmd_test_for_reboot, ping_timeout,
                  ping_attempts))

def dequote(arg_string):
    """
    If a string has single or double quotes around it, remove them.
    Make sure the pair of quotes match.
    If a matching pair of quotes is not found, return the string unchanged.
    """
    if (arg_string[0] == arg_string[-1]) and arg_string.startswith(("'", '"')):
        return arg_string[1:-1]
    return arg_string

def parser(arg_thread, arg_cfg_path):
    """
    Parse the configuration file
    """
    global FLAG_DEBUGGING, FLAG_TEST_FOR_REBOOT, host_list, remote_user_id
    global command, cmd_test_for_reboot, ping_timeout, ping_attempts
    Config = configparser.ConfigParser()
    util.log_write(arg_thread, "parser: path = %s", os.path.abspath(arg_cfg_path))
    Config.read(arg_cfg_path)
    if not Config.has_section(SECTION_NAME):
        util.log_write(arg_thread,
                       "*** parser: The config file is missing section %s",
                       SECTION_NAME)
        return False
    try:
        FLAG_DEBUGGING = Config.getboolean(SECTION_NAME, "flag_debugging")
        util.log_write(arg_thread, "parser: flag_debugging = %s", FLAG_DEBUGGING)
        FLAG_TEST_FOR_REBOOT = Config.getboolean(SECTION_NAME, "FLAG_TEST_FOR_REBOOT")
        util.log_write(arg_thread, "parser: flag_test_for_reboot = %s", FLAG_TEST_FOR_REBOOT)
        ping_timeout = Config.getint(SECTION_NAME, "ping_timeout")
        util.log_write(arg_thread, "parser: ping_timeout = %d", ping_timeout)
        ping_attempts = Config.getint(SECTION_NAME, "ping_attempts")
        util.log_write(arg_thread, "parser: ping_attempts = %d", ping_attempts)
        try:
            host_list = ast.literal_eval(Config.get(SECTION_NAME, "host_list"))
        except:
            util.log_write(arg_thread,
                           "*** parser: The config file contains a mal-formed host_list")
            return False
        util.log_write(arg_thread, "parser: host_list = %s [%d entries]",
                       str(host_list), len(host_list))
        remote_user_id = dequote(Config.get(SECTION_NAME, "remote_user_id"))
        util.log_write(arg_thread, "parser: remote_user_id = %s", remote_user_id)
        command = dequote(Config.get(SECTION_NAME, "command"))
        util.log_write(arg_thread, "parser: command = %s", command)
        if FLAG_TEST_FOR_REBOOT:
            cmd_test_for_reboot = dequote(Config.get(SECTION_NAME, "cmd_test_for_reboot"))
        else:
            cmd_test_for_reboot = "not_in_use"
        util.log_write(arg_thread, "parser: cmd_test_for_reboot = %s", cmd_test_for_reboot)
    except ValueError:
        util.log_write(arg_thread, "*** parser: The config file contains one or more value errors")
        return False
    util.log_write(arg_thread, "parser: validation completed ok")
    return True
