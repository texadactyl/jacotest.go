"""
remx utility functions
"""
import os
import subprocess
import threading
import time

import remx_cfg as cfg

THREAD_LOCK = threading.Lock()

# ----------------------------------------------------------
# Time-stamp logger initialization
# ----------------------------------------------------------
def log_open(arg_thread, arg_path):
    """
    Open log for the given thread, overwriting the file at the specified path.
    """
    THREAD_LOCK.acquire()
    arg_thread.log_path = arg_path
    arg_thread.log_handle = os.open(arg_path, os.O_CREAT | os.O_WRONLY  | os.O_TRUNC)
    THREAD_LOCK.release()

# ----------------------------------------------------------
# Time-stamp logger; API is like C-language printf
# Write to log and terminal
# ----------------------------------------------------------
def log_write(arg_thread, arg_format, *arg_list):
    """
    Write a sprintf-style message to the log for the given thread.
    """
    now = time.strftime("%Y-%m-%d %H.%M.%S", time.localtime())
    fmt = "{nstr} {threadid}.{myname}: {fstr}"\
            .format(nstr=now, threadid=arg_thread.thread_id,
                    myname=arg_thread.name, fstr=arg_format)
    msg = fmt % arg_list
    byte_array = bytes(msg + '\n', 'utf-8')
    THREAD_LOCK.acquire()
    print(msg)
    os.write(arg_thread.log_handle, byte_array)
    os.fsync(arg_thread.log_handle)
    THREAD_LOCK.release()

# ----------------------------------------------------------
# Dump a stdout string to log
# ----------------------------------------------------------
def log_stdout(arg_thread, arg_string):
    """
    Write a string to the log for the given thread.
    """
    byte_array = bytes(arg_string + '\n', 'utf-8')
    THREAD_LOCK.acquire()
    os.write(arg_thread.log_handle, byte_array)
    os.fsync(arg_thread.log_handle)
    THREAD_LOCK.release()

# ----------------------------------------------------------
# Time-stamp logger close
# ----------------------------------------------------------
def log_close(arg_thread):
    """
    Close the log for the given thread.
    """
    THREAD_LOCK.acquire()
    os.close(arg_thread.log_handle)
    THREAD_LOCK.release()

# ----------------------------------------------------------
# Ping a host
# ----------------------------------------------------------
def pinger(arg_host):
    """
    Attempt to ping the given host.
    Give up if the number of successive failures exceeds the configured threshold.
    """
    if cfg.FLAG_DEBUGGING:
        cfg.dump_parms("pinger")
    command = ["ping", "-c", "1", "-W", "{}".format(cfg.ping_timeout), arg_host]
    count_down = cfg.ping_attempts
    while count_down > 0:
        result = subprocess.run(command, check=False,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        if result.returncode == 0:
            return result
        count_down = count_down - 1
    return result

# ----------------------------------------------------------
# Execute a remote command
# ----------------------------------------------------------
def remote_exec(arg_thread):
    """
    Ping the given host.
    If successful, execute the configured command at the host.
    """
    if cfg.FLAG_DEBUGGING:
        cfg.dump_parms("remote_exec")
    try:
        result = pinger(arg_thread.name)
        if result.returncode != 0:
            log_write(arg_thread, "*** Oops, remote_exec: pinger @ %s failed: %s",
                      arg_thread.name, result.stdout)
            log_write(arg_thread, "OOPS: %s", result.stdout)
            return False
        log_write(arg_thread, "remote_exec: pinger ok @ %s", arg_thread.name)
        args = ["ssh", cfg.remote_user_id + "@" + arg_thread.name, cfg.command]
        if cfg.FLAG_DEBUGGING:
            log_write(arg_thread, "DEBUG ssh args=%s", str(args))
        result = subprocess.run(args, check=False,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        if result.returncode != 0:
            log_write(arg_thread, "*** Oops, remote_exec: `%s` @ %s failed (%d)",
                      cfg.command, arg_thread.name, result.returncode)
            log_stdout(arg_thread, result.stdout.decode())
            return False
        log_write(arg_thread, "remote_exec: completed ok @ %s", arg_thread.name)
        log_stdout(arg_thread, result.stdout.decode())
    except subprocess.SubprocessError:
        log_write(arg_thread,
                  "*** Oops, remote_exec: %s @ %s subprocess.SubprocessError exception",
                  cfg.command, arg_thread.name)
        log_stdout(arg_thread, result.stdout.decode())
        return False

    if cfg.FLAG_TEST_FOR_REBOOT:
        try:
            args = ["ssh", cfg.remote_user_id + "@" + arg_thread.name,
                    cfg.cmd_test_for_reboot]
            result = subprocess.run(args, check=False,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT)
            if result.returncode == 0:
                log_write(arg_thread, "Reboot needed @ %s", arg_thread.name)
                args = ["ssh", cfg.remote_user_id + "@" + arg_thread.name, "sudo reboot"]
                result = subprocess.run(args, check=False,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.STDOUT)
                log_write(arg_thread,
                          "Reboot result @ %s, stdout:\n%s",
                          arg_thread.name, result.stdout.decode())
            else:
                log_write(arg_thread, "No reboot needed @ %s", arg_thread.name)
        except subprocess.SubprocessError:
            log_write(arg_thread,
                      "*** Oops, remote_exec: reboot @ %s subprocess.SubprocessError exception",
                      arg_thread.name)
            log_stdout(arg_thread, result.stdout.decode())
            return False
    return True
